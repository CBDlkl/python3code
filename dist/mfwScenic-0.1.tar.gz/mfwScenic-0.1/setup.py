from distutils.core import setup

setup(
    name="mfwScenic",
    version="0.1",
    py_modules=['mafengwo.scenic', 'mysql.mysqlHelp'],
)
